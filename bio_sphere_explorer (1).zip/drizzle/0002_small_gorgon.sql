CREATE TABLE `questions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`questionId` varchar(50) NOT NULL,
	`sphere` varchar(50) NOT NULL,
	`questionText` text NOT NULL,
	`answers` text NOT NULL,
	`correctAnswerIndex` int NOT NULL,
	`explanation` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `questions_id` PRIMARY KEY(`id`),
	CONSTRAINT `questions_questionId_unique` UNIQUE(`questionId`)
);
--> statement-breakpoint
CREATE TABLE `studentAccounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`studentNumber` varchar(50) NOT NULL,
	`studentName` varchar(255) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `studentAccounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `studentAccounts_studentNumber_unique` UNIQUE(`studentNumber`)
);
--> statement-breakpoint
CREATE TABLE `teacherAccounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`teacherCode` varchar(50) NOT NULL,
	`teacherName` varchar(255) NOT NULL,
	`password` varchar(255) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `teacherAccounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `teacherAccounts_teacherCode_unique` UNIQUE(`teacherCode`)
);
--> statement-breakpoint
ALTER TABLE `gameSessions` DROP FOREIGN KEY `gameSessions_userId_users_id_fk`;
--> statement-breakpoint
ALTER TABLE `gameSessions` ADD `studentId` int NOT NULL;--> statement-breakpoint
ALTER TABLE `gameSessions` ADD CONSTRAINT `gameSessions_studentId_studentAccounts_id_fk` FOREIGN KEY (`studentId`) REFERENCES `studentAccounts`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `gameSessions` DROP COLUMN `studentName`;--> statement-breakpoint
ALTER TABLE `gameSessions` DROP COLUMN `studentEmail`;--> statement-breakpoint
ALTER TABLE `gameSessions` DROP COLUMN `userId`;