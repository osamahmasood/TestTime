import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Student accounts table - stores student login credentials
 */
export const studentAccounts = mysqlTable("studentAccounts", {
  id: int("id").autoincrement().primaryKey(),
  studentNumber: varchar("studentNumber", { length: 50 }).notNull().unique(),
  studentName: varchar("studentName", { length: 255 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type StudentAccount = typeof studentAccounts.$inferSelect;
export type InsertStudentAccount = typeof studentAccounts.$inferInsert;

/**
 * Teacher accounts table - stores teacher login credentials
 */
export const teacherAccounts = mysqlTable("teacherAccounts", {
  id: int("id").autoincrement().primaryKey(),
  teacherCode: varchar("teacherCode", { length: 50 }).notNull().unique(),
  teacherName: varchar("teacherName", { length: 255 }).notNull(),
  password: varchar("password", { length: 255 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TeacherAccount = typeof teacherAccounts.$inferSelect;
export type InsertTeacherAccount = typeof teacherAccounts.$inferInsert;

/**
 * Questions table - stores all quiz questions
 */
export const questions = mysqlTable("questions", {
  id: int("id").autoincrement().primaryKey(),
  questionId: varchar("questionId", { length: 50 }).notNull().unique(),
  sphere: varchar("sphere", { length: 50 }).notNull(),
  questionText: text("questionText").notNull(),
  answers: text("answers").notNull(),
  correctAnswerIndex: int("correctAnswerIndex").notNull(),
  explanation: text("explanation"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Question = typeof questions.$inferSelect;
export type InsertQuestion = typeof questions.$inferInsert;

/**
 * Game sessions table - tracks each student's game session
 */
export const gameSessions = mysqlTable("gameSessions", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").notNull().references(() => studentAccounts.id),
  startTime: timestamp("startTime").defaultNow().notNull(),
  endTime: timestamp("endTime"),
  totalScore: int("totalScore").default(0),
  totalQuestions: int("totalQuestions").default(30),
  completedSpheres: int("completedSpheres").default(0),
  isCompleted: int("isCompleted").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type GameSession = typeof gameSessions.$inferSelect;
export type InsertGameSession = typeof gameSessions.$inferInsert;

/**
 * Student results table - tracks detailed results for each sphere
 */
export const studentResults = mysqlTable("studentResults", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull().references(() => gameSessions.id),
  sphere: varchar("sphere", { length: 50 }).notNull(),
  questionsAttempted: int("questionsAttempted").default(0),
  correctAnswers: int("correctAnswers").default(0),
  sphereScore: int("sphereScore").default(0),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type StudentResult = typeof studentResults.$inferSelect;
export type InsertStudentResult = typeof studentResults.$inferInsert;

/**
 * Question responses table - tracks individual question responses
 */
export const questionResponses = mysqlTable("questionResponses", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull().references(() => gameSessions.id),
  questionId: varchar("questionId", { length: 50 }).notNull(),
  sphere: varchar("sphere", { length: 50 }).notNull(),
  selectedAnswerIndex: int("selectedAnswerIndex"),
  isCorrect: int("isCorrect").default(0),
  responseTime: int("responseTime"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type QuestionResponse = typeof questionResponses.$inferSelect;
export type InsertQuestionResponse = typeof questionResponses.$inferInsert;
