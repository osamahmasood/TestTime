CREATE TABLE `gameSessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`studentName` varchar(255) NOT NULL,
	`studentEmail` varchar(320),
	`userId` int,
	`startTime` timestamp NOT NULL DEFAULT (now()),
	`endTime` timestamp,
	`totalScore` int DEFAULT 0,
	`totalQuestions` int DEFAULT 30,
	`completedSpheres` int DEFAULT 0,
	`isCompleted` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `gameSessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `questionResponses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`questionId` varchar(50) NOT NULL,
	`sphere` varchar(50) NOT NULL,
	`selectedAnswerIndex` int,
	`isCorrect` int DEFAULT 0,
	`responseTime` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `questionResponses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `studentResults` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`sphere` varchar(50) NOT NULL,
	`questionsAttempted` int DEFAULT 0,
	`correctAnswers` int DEFAULT 0,
	`sphereScore` int DEFAULT 0,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `studentResults_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `gameSessions` ADD CONSTRAINT `gameSessions_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `questionResponses` ADD CONSTRAINT `questionResponses_sessionId_gameSessions_id_fk` FOREIGN KEY (`sessionId`) REFERENCES `gameSessions`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `studentResults` ADD CONSTRAINT `studentResults_sessionId_gameSessions_id_fk` FOREIGN KEY (`sessionId`) REFERENCES `gameSessions`(`id`) ON DELETE no action ON UPDATE no action;